import { Component } from '@angular/core';

@Component({
  selector: 'app-filho2',
  templateUrl: './filho2.component.html',
  styleUrl: './filho2.component.scss'
})
export class Filho2Component {

}
