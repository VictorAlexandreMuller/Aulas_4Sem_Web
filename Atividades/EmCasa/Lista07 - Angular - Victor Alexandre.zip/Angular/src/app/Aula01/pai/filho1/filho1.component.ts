import { Component } from '@angular/core';

@Component({
  selector: 'app-filho1',
  templateUrl: './filho1.component.html',
  styleUrl: './filho1.component.scss'
})
export class Filho1Component {

}
