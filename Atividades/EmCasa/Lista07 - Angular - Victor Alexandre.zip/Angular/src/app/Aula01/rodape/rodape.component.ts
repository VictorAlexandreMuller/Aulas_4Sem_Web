import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../aula04/usuario/usuario.service';

@Component({
  selector: 'app-rodape',
  templateUrl: './rodape.component.html',
  styleUrls: ['./rodape.component.scss'], // Corrigido para styleUrls (plural)
})
export class RodapeComponent implements OnInit {
  usuarioLogado: { email: string; senha: string } | null = null;

  constructor(private userService: UsuarioService) {}

  ngOnInit(): void {
    console.log(this.obterDadosUsuario())
    this.obterDadosUsuario();
  }

  obterDadosUsuario(): void {
    this.usuarioLogado = this.userService.getDadosUsuario();
    console.log('Dados do usuário:', this.usuarioLogado);
  }
}
