import { Component } from '@angular/core';
import { UsuarioService } from '../../../aula04/usuario/usuario.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'], // Corrigido para styleUrls (plural)
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  constructor(private userService: UsuarioService, private router: Router) {}

  login() {
    // Cria o objeto do usuário com os dados preenchidos
    const user = {
      email: this.email,
      senha: this.password,
    };

    // Chama o método login do service e salva o usuário
    this.userService.login(user);

    // Navega para a rota principal após o login
    this.router.navigate(['/principal']);
  }
}
