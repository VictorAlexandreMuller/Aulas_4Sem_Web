import { Component } from '@angular/core';

@Component({
  selector: 'app-aula-atribute-binding',
  templateUrl: './aula-atribute-binding.component.html',
  styleUrl: './aula-atribute-binding.component.scss'
})
export class AulaAtributeBindingComponent {
  tituloDoBotao = 'Clique aqui';
}
