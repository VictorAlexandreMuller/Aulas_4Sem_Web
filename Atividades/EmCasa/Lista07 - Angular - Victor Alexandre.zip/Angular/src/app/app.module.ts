import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Aula01/components/login/login.component';
import { PrincipalComponent } from './Aula01/components/principal/principal.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PaiComponent } from './Aula01/pai/pai.component';
import { PrimeiroComponenteComponent } from './Aula01/primeiro-componente/primeiro-componente.component';
import { MenuSuperiorComponent } from './Aula01/menu-superior/menu-superior.component';
import { RodapeComponent } from './Aula01/rodape/rodape.component';
import { Filho1Component } from './Aula01/pai/filho1/filho1.component';
import { Filho2Component } from './Aula01/pai/filho2/filho2.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DiretivasEstruturaisComponent } from './aula04/diretivas-estruturais/diretivas-estruturais.component';
import { ClientesComponent } from './aula04/clientes/clientes.component';
import { DiretivaNgifComponent } from './aula04/diretiva-ngif/diretiva-ngif.component';
import { DiretivaNgforComponent } from './aula04/diretiva-ngfor/diretiva-ngfor.component';
import { Lista03Component } from './aula04/lista/lista03/lista03.component';
import { SetClienteComponent } from './aula04/lista/set-cliente/set-cliente.component';
import { UpdateClienteComponent } from './aula04/lista/update-cliente/update-cliente.component';
import { DeleteClienteComponent } from './aula04/lista/delete-cliente/delete-cliente.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    PrincipalComponent,
    PaiComponent,
    PrimeiroComponenteComponent,
    MenuSuperiorComponent,
    RodapeComponent,
    Filho1Component,
    Filho2Component,
    DiretivasEstruturaisComponent,
    ClientesComponent,
    DiretivaNgifComponent,
    DiretivaNgforComponent,
    Lista03Component,
    SetClienteComponent,
    UpdateClienteComponent,
    DeleteClienteComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
