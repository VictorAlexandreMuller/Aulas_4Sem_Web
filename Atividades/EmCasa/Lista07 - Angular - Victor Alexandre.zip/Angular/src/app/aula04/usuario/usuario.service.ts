import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UsuarioService {
  constructor() {}

  // Função de login que salva os dados do usuário no localStorage
  login(usuario: { email: string, senha: string }): void {
    // Salva os dados de login no localStorage como uma string JSON
    localStorage.setItem('usuario', JSON.stringify(usuario));
  }

  // Função para obter os dados do usuário do localStorage
  getDadosUsuario(): { email: string, senha: string } | null {
    // Recupera os dados de login do localStorage
    const usuarioData = localStorage.getItem('usuario');

    // Verifica se há dados no localStorage e retorna o objeto convertido ou null
    return usuarioData ? JSON.parse(usuarioData) : null;
  }
}
