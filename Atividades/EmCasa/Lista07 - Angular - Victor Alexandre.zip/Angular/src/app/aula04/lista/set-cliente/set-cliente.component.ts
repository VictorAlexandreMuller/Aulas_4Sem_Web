import { Component } from '@angular/core';
import { ClientesService } from '../../clientes.service';

@Component({
  selector: 'app-set-cliente',
  templateUrl: './set-cliente.component.html',
  styleUrl: './set-cliente.component.scss',
})
export class SetClienteComponent {
  nome: string = '';
  rg!: number;
  cpf!: number;
  email: string = '';
  telefone!: number;
  celular!: number;
  cep!: number;
  endereco: string = '';
  numero!: number;
  complemento: string = '';
  bairro: string = '';
  cidade: string = '';
  estado: string = '';

  cliente!: any;

  constructor(private clienteService: ClientesService) {}

  cadastrarCliente(cliente: any) {
    cliente = {
      nome: this.nome,
      rg: this.rg,
      cpf: this.cpf,
      email: this.email,
      telefone: this.telefone,
      celular: this.celular,
      cep: this.cep,
      endereco: this.endereco,
      numero: this.numero,
      complemento: this.complemento,
      bairro: this.bairro,
      cidade: this.cidade,
      estado: this.estado,
    };
    this.clienteService
      .setCliente(cliente)
      .then((response) => window.alert(`POST response:', ${response}`))
      .catch((error) => window.alert(error));
  }
}
