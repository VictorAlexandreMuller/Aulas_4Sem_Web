import { Component } from '@angular/core';
import { ClientesService } from '../../clientes.service';

@Component({
  selector: 'app-delete-cliente',
  templateUrl: './delete-cliente.component.html',
  styleUrl: './delete-cliente.component.scss'
})
export class DeleteClienteComponent {

  id!:number
  constructor(private clienteService: ClientesService){}

  deletarCliente(id:number){
    this.clienteService.deleteCliente(id).then((response) => window.alert(`POST response:', ${response}`))
    .catch((error) => window.alert(error));
  }
}
