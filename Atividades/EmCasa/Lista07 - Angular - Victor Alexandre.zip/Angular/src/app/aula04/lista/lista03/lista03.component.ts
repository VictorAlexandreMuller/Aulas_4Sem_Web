import { Component } from '@angular/core';
import { ClientesService } from '../../clientes.service';

@Component({
  selector: 'app-lista03',
  templateUrl: './lista03.component.html',
  styleUrl: './lista03.component.scss'
})
export class Lista03Component {

  id!: number
  clientes:any = []

  constructor(private clienteService: ClientesService){

  }

  buscarClientes(id : number | null){

    if(id != null){
      this.clienteService.getCliente(id).then((data) => {
        console.log(data);
        this.clientes = data;
      });
    }else{
      this.clienteService.getClientes().then((data) => {
        console.log(data);
        this.clientes = data;
      });
    }
  }
}
