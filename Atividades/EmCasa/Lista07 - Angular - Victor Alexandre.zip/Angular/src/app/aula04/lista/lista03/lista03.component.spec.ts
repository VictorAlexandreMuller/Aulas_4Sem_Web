import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Lista03Component } from './lista03.component';

describe('Lista03Component', () => {
  let component: Lista03Component;
  let fixture: ComponentFixture<Lista03Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Lista03Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Lista03Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
