import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SetClienteComponent } from './set-cliente.component';

describe('SetClienteComponent', () => {
  let component: SetClienteComponent;
  let fixture: ComponentFixture<SetClienteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SetClienteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SetClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
