import { Component } from '@angular/core';

@Component({
  selector: 'app-diretivas-estruturais',
  templateUrl: './diretivas-estruturais.component.html',
  styleUrl: './diretivas-estruturais.component.scss'
})
export class DiretivasEstruturaisComponent {

}
