import { Component } from '@angular/core';

@Component({
  selector: 'app-diretiva-ngfor',
  templateUrl: './diretiva-ngfor.component.html',
  styleUrl: './diretiva-ngfor.component.scss',
})
export class DiretivaNgforComponent {
  listaGeral: any = ['Edson', 30, true];
  listaPessoas = [
    {nome: "Lucas", idade: 20, ativo: true},
    {nome: "Laysa", idade: 20, ativo: true},
    {nome: "Edson", idade: 40, ativo: true}
  ]
}
