import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormComponent } from './form/form.component';
import { NavbarComponent } from './navbar/navbar.component';
import { CalculadoraComponent } from './calculadora/calculadora.component';
import { CadastroComponent } from './cadastro/cadastro.component';
import { ApoliceComponent } from './apolice/apolice.component';

const routes: Routes = [
  { path: 'formulario', component: FormComponent }, // Defina a rota
  { path: '', redirectTo: '/formulario', pathMatch: 'full' }, // Redirecionamento padrão (opcional)
  { path: 'calculadora', component: CalculadoraComponent },
  { path: 'cadastro', component: CadastroComponent },
  { path: 'apolice', component: ApoliceComponent } // Defina a rota
  // { path: '', redirectTo: '/calculadora', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
