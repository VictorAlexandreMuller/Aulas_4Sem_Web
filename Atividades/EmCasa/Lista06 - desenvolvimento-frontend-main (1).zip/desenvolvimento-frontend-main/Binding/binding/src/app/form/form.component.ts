import { Component } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrl: './form.component.css'
})
export class FormComponent {
  ac1!: number;
  ac2!: number;
  ag!: number;
  af!: number;
  media!: number;
  aprovacao!: string;
  
  onSubmit() {
    this.media = this.calcularMedia(this.ac1, this.ac2, this.ag, this.af);

    if (this.media >= 5) {
      this.aprovacao = "Aprovado!";
    } else {
      this.aprovacao = "Reprovado!";
    }
    
  }

  calcularMedia(ac1: number, ac2: number, ag:number, af:number) {
    const media = (ac1 * 0.15) + (ac2*0.30) + (ag * 0.10) + (af * 0.45);

    return Math.floor(media * 100) / 100;
  }
}
