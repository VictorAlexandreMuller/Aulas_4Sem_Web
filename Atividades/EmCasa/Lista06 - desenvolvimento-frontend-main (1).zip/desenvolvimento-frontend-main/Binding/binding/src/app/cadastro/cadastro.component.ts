import { Component } from '@angular/core';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrl: './cadastro.component.css'
})
export class CadastroComponent {
ra!: string
nome!: string
email!: string
celular!: string
aluno!: string

  onSubmit() {
    this.aluno = `RA: ${this.ra}, Nome: ${this.nome}, Email: ${this.email}, Celular: ${this.celular}`;
  }
}
