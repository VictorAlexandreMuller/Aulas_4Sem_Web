import { Component } from '@angular/core';
import { NumberValueAccessor } from '@angular/forms';

@Component({
  selector: 'app-calculadora',
  templateUrl: './calculadora.component.html',
  styleUrl: './calculadora.component.css'
})
export class CalculadoraComponent {
  num1!: number;
  num2!: number;
  operacao!: string
  resultado!: number;

  onSubmit() {
    switch (this.operacao) {
      case "soma":
        this.resultado = this.num1 + this.num2;
        break;
      case "subtracao":
        this.resultado = this.num1 - this.num2;
        break;
      case "multiplicacao":
        this.resultado = this.num1 * this.num2;
        break;
      case "divisao":
        if (this.num2 !== 0) {
          this.resultado = this.num1 / this.num2;
    }
  }
  }
}
